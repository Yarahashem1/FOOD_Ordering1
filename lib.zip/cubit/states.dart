abstract class AppStates {}

class AppInitialState extends AppStates {}